void trivial() { /* comment */}
