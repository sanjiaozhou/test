b_in_wf = pmr_fce_ceof_wf->modulo(1/*NT*/ * 12/*12 raw*/ * 12/*#column*/).base(12*12*sym_idx).start(12*12*sym_idx);
